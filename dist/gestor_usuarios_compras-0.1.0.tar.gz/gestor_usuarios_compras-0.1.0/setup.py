from setuptools import setup, find_packages

setup(
    name="gestor_usuarios_compras",
    version="0.1.0",
    author="Marcos Reyero",
    author_email="reyeromateo@gmail.com",
    description="Sistema de Gestión de Usuarios y Compras en Línea",
    packages=find_packages(),  # Usa find_packages() para encontrar todos los paquetes automáticamente
    entry_points={
        'console_scripts': [
            'gestor-usuarios-compras=gestor_de_usuarios.main:main',
        ],
    },
    include_package_data=True,
    package_data={
        '': ['*.txt', '*.rst'],
        'gestor_de_usuarios': ['*.py'],
    },
)
